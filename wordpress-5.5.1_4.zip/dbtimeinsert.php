<?php
    session_start();
    include_once("dbconnect.php");
    if(isset($_POST['log_time'])) {
        if($_POST['log_time'] != "") {
            $time = $_POST['log_time'];
            $sql_store = "INSERT into time_stamp (id, time) VALUES (NULL, '$time')";
            $sql = mysqli_query($db, $sql_store) or die(mysql_error());
        }
    }
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	exit();
?>