<?php
    $db = mysqli_connect("aa1y22yamu0v6b.cbffzvohl83v.us-east-1.rds.amazonaws.com", "csci2999yellow", "Y0uHav3F0undYellow!", "ebdb")
?>